package com.example.host_0303.xposednani.util;

public class PackageUtil {
    public final static String BAIDU_NANI_PACKAGE = "com.baidu.nani";
    public final static String CLASSPATH_MAINACTIVITY = "com.baidu.nani.MainActivity";
    public final static String CLASSPATH_DISCOVER_FRAGMENT = "com.baidu.nani.discover.DiscoverFragment";
    public final static String CLASSPATH_SEARCH_ACTIVITY = "com.baidu.nani.search.SearchActivity";
    public final static String CLASSPATH_PERSON_TABLE_FRAGMENT = "com.baidu.nani.person.PersonTabFragment";
    public final static String CLASSPATH_RECYCLEVIEW_G = "com.baidu.nani.corelib.widget.recyclerview.g";
    public final static String CLASSPATH_VIDEO_PLAY_FRAGMENT_VIEW_BINDING = "com.baidu.nani.videoplay.VideoPlayFragment_ViewBinding";
    public final static String CLASSPATH_VIDEO_COMMENT_ACTIVITY = "com.baidu.nani.videoplay.comment.VideoCommentActivity";
    public final static String CLASSPATH_SEARCH_RESULT_DATA = "com.baidu.nani.search.data.SearchResult$Data";
    public final static String CLASSPATH_RECYCLER_VIEW$H = "android.support.v7.widget.RecyclerView$h";
    public final static String CLASSPATH_VIDEO_PLAY_FRAGMENT = "com.baidu.nani.videoplay.VideoPlayFragment";
}
