package com.example.host_0303.xposednani.util;

public class CommitsUtil {
    public static String[] COMMITS= {
            "好看！",
            "真好，哇，好漂亮",
            "加油"
    };
}
